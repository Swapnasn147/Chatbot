# chatbot
chatbot coded in videos part wise

watch full tutorial video
videos : https://youtu.be/CSpsB4_-5WQ

kaggle  : https://www.kaggle.com/programminghut/seq2seq-chatbot-keras
